#mod-basiclti-view .description
{
	margin-top: 15px;
}
#mod-basiclti-view .activity
{
	text-align: center;
	
}
