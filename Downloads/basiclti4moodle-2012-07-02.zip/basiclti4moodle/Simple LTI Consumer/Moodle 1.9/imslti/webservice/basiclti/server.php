<?php


echo '<?xml version="1.0" encoding="UTF-8"?>' .
		'<launchResponse>' .
		'<status>success</status>' .
		'<type>iFrame</type>' .
		'<launchUrl>http://potato.lsi.upc.edu/moodle20beta/</launchUrl>' .
	 	'</launchResponse>';

?>