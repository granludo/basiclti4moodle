<?php

require_once('../../config.php');
global $CFG, $USER, $COURSE, $DB;

require_once($CFG->libdir.'/moodlelib.php');
require_once($CFG->dirroot.'/mod/basiclti/locallib.php');

$url = required_param('url', PARAM_TEXT);
$id = required_param('id', PARAM_TEXT);

$basiclti = $DB->get_record('basiclti', array('id' => $id));

$context = get_context_instance(CONTEXT_MODULE, $id);
$role = basiclti_get_ims_role($USER, $context);

$cm = get_coursemodule_from_instance('basiclti', $id);

$date = basiclti_get_date();
$nonce = basiclti_nonce();
$digest = basiclti_digest($nonce, $date, $basiclti->password);

echo '
<html>
<body>
	<div>'.get_string('redirect','basiclti').'</div>
	<form action="'.$url.'" name="ltiLaunchForm"
          method="post">

		 <input type="hidden" size="40" name="action" value="direct"/>
		 <input type="hidden" size="40" name="sec_nonce"
		 		value="'.$nonce.'"/>
		 <input type="hidden" size="40" name="sec_created"
             	value="'.$date.'"/>
		 <input type="hidden" size="40" name="sec_digest"
            	value="'.$digest.'"/>
		 <input type="hidden" size="40" name="sec_org_digest"
            	value="'.$digest.'"/>
		 <input type="hidden" size="40" name="user_id"
		 		value="'.$USER->id.'"/>
		 <input type="hidden" size="40" name="user_role"
		 		value="'.$role.'"/>
		 <input type="hidden" size="40" name="course_id"
		 		value="'.$cm->course.'"/>
		 <input type="submit" value="'.get_string('continue').'">
	</form>

	<script>
	setTimeout("document.ltiLaunchForm.submit();",4000);
	</script>
</body>
<html>';

?>