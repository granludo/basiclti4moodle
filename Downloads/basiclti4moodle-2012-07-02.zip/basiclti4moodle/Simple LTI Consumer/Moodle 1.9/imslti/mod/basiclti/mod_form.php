<?php

/**
 * This file defines de main basiclti configuration form
 *
 * @author Jordi Piguillem
 *
 * @license http://www.gnu.org/copyleft/gpl.html GNU Public License
 * @package basiclti
 */

require_once ($CFG->dirroot.'/course/moodleform_mod.php');
require_once ($CFG->dirroot.'/mod/basiclti/locallib.php');

class mod_basiclti_mod_form extends moodleform_mod {

	function definition() {

		global $COURSE, $DB;

		$typename = optional_param('type',false, PARAM_ALPHA);

		if (empty($typename)){
			//Updating instance
			if (!empty($this->_instance)){
				$basiclti = $DB->get_record('basiclti', array('id' => $this->_instance));
				$this->typeid = $basiclti->typeid;
			// New not pre-configured instance
			} else {
				$this->typeid = 0;
			}
		} else {
			// New pre-configured instance
			$basicltitype = $DB->get_record('basiclti_types', array('rawname' => $typename));
			$this->typeid = $basicltitype->id;
		}

		$typeconfig = basiclti_get_type_config($this->typeid);
		$this->typeconfig = $typeconfig;

		$mform    =& $this->_form;

//-------------------------------------------------------------------------------
    /// Adding the "general" fieldset, where all the common settings are showed
        $mform->addElement('header', 'general', get_string('general', 'form'));
    /// Adding the standard "name" field
        $mform->addElement('text', 'name', get_string('basicltiname', 'basiclti'), array('size'=>'64'));
		$mform->setType('name', PARAM_TEXT);
		$mform->addRule('name', null, 'required', null, 'client');
    /// Adding the optional "intro" and "introformat" pair of fields
		$this->add_intro_editor(true, get_string('basicltiintro', 'basiclti'));

//-------------------------------------------------------------------------------
		// add basiclti elements
		/// Adding the "general" fieldset, where all the common settings are showed
        $mform->addElement('header', 'basicltisettings', get_string('basicltisettings', 'basiclti'));
		$regex = '/^(http|https):\/\/([a-z0-9-]\.+)*/i';

		if(isset($typeconfig['toolurl'])){
			$mform->addElement('hidden', 'toolurl', get_string('toolurl','basiclti'));
		} else {
			$mform->addElement('text', 'toolurl', get_string('toolurl','basiclti'), array('size'=>'64'));
			$mform->addRule('toolurl', null, 'required', null, 'client');
			$mform->addRule('toolurl',get_string('validurl','basiclti'), 'regex', $regex, 'client');
		}
	    $mform->setType('toolurl', PARAM_TEXT);


		if(isset($typeconfig['password'])){
			$mform->addElement('hidden', 'password', get_string('password','basiclti'));
		} else {
			$mform->addElement('passwordunmask', 'password', get_string('password','basiclti'));
			$mform->addRule('password', null, 'required', null, 'client');
		}
		$mform->setType('password', PARAM_TEXT);


		if(isset($typeconfig['resourceurl'])){
			$mform->addElement('hidden', 'resourceurl', get_string('resourceurl','basiclti'));
		} else {
			$mform->addElement('text', 'resourceurl', get_string('resourceurl','basiclti'),array('size'=>'64'));
			$mform->addRule('resourceurl',get_string('validurl','basiclti'), 'regex', $regex, 'client');
			$mform->setHelpButton('resourceurl', array('resourceurl', get_string('resourceurl', 'basiclti'), 'basiclti'));
			$mform->setAdvanced('resourceurl');
		}
        $mform->setType('resourceurl', PARAM_TEXT);


		if(isset($typeconfig['preferwidget'])){
			$mform->addElement('hidden', 'preferwidget', get_string('preferwidget', 'basiclti'),null, array('disabled'=>'disabled'));
		} else {
			$mform->addElement('checkbox', 'preferwidget', get_string('preferwidget', 'basiclti'));
			$mform->setHelpButton('preferwidget', array('preferwidget', get_string('preferwidget', 'basiclti'), 'basiclti'));
			$mform->setAdvanced('preferwidget');
		}


		if(isset($typeconfig['preferwidth'])){
			$mform->addElement('hidden', 'preferwidth', get_string('preferwidth','basiclti'));
		} else {
			$mform->addElement('text', 'preferwidth', get_string('preferwidth','basiclti'));
			$mform->setHelpButton('preferwidth', array('preferwidth', get_string('preferwidth', 'basiclti'), 'basiclti'));
			$mform->setAdvanced('preferwidth');
		}
        $mform->setType('preferwidth', PARAM_INT);


		if(isset($typeconfig['preferheight'])){
			$mform->addElement('hidden', 'preferheight', get_string('preferheight','basiclti'));
		} else {
			$mform->addElement('text', 'preferheight', get_string('preferheight','basiclti'));
			$mform->setHelpButton('preferheight', array('preferheight', get_string('preferheight', 'basiclti'), 'basiclti'));
			$mform->setAdvanced('preferheight');
		}
        $mform->setType('preferheight', PARAM_INT);

		$mform->addElement('hidden', 'typeid', get_string('preferheight','basiclti'));
//-------------------------------------------------------------------------------
		// add standard elements, common to all modules
		$this->standard_coursemodule_elements();
//-------------------------------------------------------------------------------
        // add standard buttons, common to all modules
        $this->add_action_buttons();

	}

    /**
     * Function overwrited to change default values using
     * global configuration
     *
     * @param array $default_values passed by reference
     */
    function data_preprocessing(&$default_values){
		global $CFG;

		$default_values['typeid'] = $this->typeid;

		if (!isset($default_values['toolurl'])){

			if (isset($this->typeconfig['toolurl'])){
				$default_values['toolurl'] = $this->typeconfig['toolurl'];
			} elseif (isset($CFG->basiclti_resourceurl)){
				$default_values['toolurl'] = $CFG->basiclti_resourceurl;
			}
		}

		if (!isset($default_values['password'])){

			if (isset($this->typeconfig['password'])){
				$default_values['password'] = $this->typeconfig['password'];
			} elseif (isset($CFG->basiclti_password)){
				$default_values['password'] = $CFG->basiclti_password;
			}
		}

		if (!isset($default_values['resourceurl'])){
			if (isset($this->typeconfig['resourceurl'])){
				$default_values['resourceurl'] = $this->typeconfig['resourceurl'];
			} elseif (isset($CFG->basiclti_resourceurl)){
				$default_values['resourceurl'] = $CFG->basiclti_resourceurl;
			}
		}

		if (!isset($default_values['preferwidget'])){
			if (isset($this->typeconfig['preferwidget'])){
				$default_values['preferwidget'] = $this->typeconfig['preferwidget'];
			} elseif (isset($CFG->basiclti_preferwidget)){
				$default_values['preferwidget'] = $CFG->basiclti_preferwidget;
			}
		}

		if (!isset($default_values['preferwidth'])){
			if (isset($this->typeconfig['preferwidth'])){
				$default_values['preferwidth'] = $this->typeconfig['preferwidth'];
			} elseif (isset($CFG->basiclti_preferwidth)){
				$default_values['preferwidth'] = $CFG->basiclti_preferwidth;
			}
		}

		if (!isset($default_values['preferheight'])){
			if (isset($this->typeconfig['preferheight'])){
				$default_values['preferheight'] = $this->typeconfig['preferheight'];
			} elseif (isset($CFG->basiclti_preferheight)){
				$default_values['preferheight'] = $CFG->basiclti_preferheight;
			}
		}
    }

}

?>
