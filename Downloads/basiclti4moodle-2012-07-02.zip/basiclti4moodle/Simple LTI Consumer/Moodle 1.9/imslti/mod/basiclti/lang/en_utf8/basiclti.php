<?php
/**
 *
 * This file contains en_utf8 translation of Basic LTI module
 *
 * @author Jordi Piguillem
 *
 * @license http://www.gnu.org/copyleft/gpl.html GNU Public License
 * @package basiclti
 */

$string['addserver'] = 'Add new trusted server';
$string['addtype'] = 'Create a new Basic LTI activity type';
$string['configpassword'] = 'Default Remote Tool Password';
$string['configpreferheight'] = 'Default preferred height';
$string['configpreferwidget'] = 'Set widget as default launch';
$string['configpreferwidth'] = 'Default preferred width';
$string['configresourceurl'] = 'Default Resource URL';
$string['configtoolurl'] = 'Default Remote Tool URL';
$string['configtypes'] = 'Configure Basic LTI types';
$string['filterconfig'] = 'Basic LTI administation';
$string['filtername'] = 'Basic LTI';
$string['filter_basiclti_configlink'] = 'Configure your preferred sites and their passwords';
$string['filter_basiclti_password'] = 'Password is mandatory';
$string['modulename'] = 'Basic LTI';
$string['modulenameplural'] = 'basicltis';
$string['noservers'] = 'No servers found';
$string['notypes'] = 'No pre-configured activities found';
$string['password'] = 'Remote Tool Password';
$string['preferheight'] = 'Preferred Height';
$string['preferwidget'] = 'Prefer Widget Launch';
$string['preferwidth'] = 'Preferred Width';
$string['redirect'] = 'You will be redirected in few seconds. If you are not, press the button.';
$string['resourceurl'] = 'Resource URL';
$string['basiclti'] = 'Basic LTI';
$string['basicltiactivities'] = 'Basic LTI Activities';
$string['basicltifieldset'] = 'Custom example fieldset';
$string['basicltiintro'] = 'Basiclti Description';
$string['basicltiname'] = 'Basiclti Name';
$string['basicltisettings'] = 'Basic Learning Tool Interoperability Settings';
$string['toolurl'] = 'Remote Tool URL';
$string['validurl'] = 'A valid URL must start with http(s)://';

?>
