<?php
/**
 * This file defines de global basiclti administration form
 * 
 * @author Jordi Piguillem
 * 
 * @license http://www.gnu.org/copyleft/gpl.html GNU Public License
 * @package basiclti
 */

require_once('localadminlib.php');

$settings->add(new admin_setting_configtext('basiclti_toolurl', get_string('toolurl', 'basiclti'),
                   get_string('configtoolurl', 'basiclti'),''));

$settings->add(new admin_setting_configpasswordunmask('basiclti_password', get_string('password', 'basiclti'),
                   get_string('configpassword', 'basiclti'),''));

$settings->add(new admin_setting_configtext('basiclti_resourceurl', get_string('resourceurl', 'basiclti'),
                   get_string('configresourceurl', 'basiclti'),''));				   		

$settings->add(new admin_setting_configcheckbox('basiclti_preferwidget', get_string('preferwidget', 'basiclti'),
                   get_string('configpreferwidget', 'basiclti'), false, array('true','false')));
				   
$settings->add(new admin_setting_configtext('basiclti_preferwidth', get_string('preferwidth', 'basiclti'),
                   get_string('configpreferwidth', 'basiclti'),''));

$settings->add(new admin_setting_configtext('basiclti_preferheight', get_string('preferheight', 'basiclti'),
                   get_string('configpreferheight', 'basiclti'),''));	
				   
$settings->add(new admin_setting_basicltimodule_configlink('basiclti_types', get_string('types', 'basiclti'),
                   get_string('configtypes', 'basiclti'),''));					   			   		

 
 
?>