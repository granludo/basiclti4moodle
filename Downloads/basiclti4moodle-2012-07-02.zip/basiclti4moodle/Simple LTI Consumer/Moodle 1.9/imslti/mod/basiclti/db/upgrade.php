<?php

/**
 *
 * This file keeps track of upgrades to the basiclti module
 *
 * @author Jordi Piguillem
 *
 * @license http://www.gnu.org/copyleft/gpl.html GNU Public License
 * @package basiclti
 */


/**
 * xmldb_basiclti_upgrade is the function that upgrades Moodle's
 * database when is needed
 *
 * This function is automaticly called when version number in
 * version.php changes.
 *
 * @param int $oldversion New old version number.
 *
 * @return boolean
 */

function xmldb_basiclti_upgrade($oldversion=0) {

    global $CFG, $THEME, $db;

    $result = true;

/// if ($result && $oldversion < YYYYMMDD00) { //New version in version.php
///     $result = result of "/lib/ddllib.php" function calls
/// }


    return $result;
}

?>
