<?php

/**
 *
 * This file contains some functions and classes used in Simple LTI
 * module administration
 *
 * @author Jordi Piguillem
 *
 * @license http://www.gnu.org/copyleft/gpl.html GNU Public License
 * @package basiclti
 */

require_once($CFG->libdir.'/adminlib.php');

/**
 *
 * @TODO: finish doc this class and it's functions
 */
class admin_setting_basicltimodule_configlink extends admin_setting {

    /**
     * Constructor
     * @param string $name of setting
     * @param string $visiblename localised
     * @param string $description long localised info
     */
    function admin_setting_basicltimodule_configlink($name, $visiblename, $description) {
        parent::__construct($name, $visiblename, $description, '');
    }

    function get_setting() {
        return true;
    }

    function output_html($data, $query='') {
		global $CFG;
        return format_admin_setting($this, "",
                '<div class="defaultsnext" >'.
                '<a href="'.$CFG->wwwroot.'/mod/basiclti/typessettings.php">'.get_string('filterconfig', 'basiclti').'</a>'.
                '</div>',
                $this->description, true, '', null, $query);
    }

    function write_setting($data){
    	return true;
    }
}
?>