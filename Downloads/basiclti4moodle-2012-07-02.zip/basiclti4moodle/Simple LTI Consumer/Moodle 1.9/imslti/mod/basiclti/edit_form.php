<?php 

/**
 * This file defines de main basiclti configuration form
 * 
 * @author Jordi Piguillem
 * 
 * @license http://www.gnu.org/copyleft/gpl.html GNU Public License
 * @package basiclti
 */

require_once ($CFG->libdir.'/formslib.php');

class mod_basiclti_edit_types_form extends moodleform{

	function definition() {

		global $COURSE;
		$mform    =& $this->_form;

//-------------------------------------------------------------------------------
		// add basiclti elements
		$mform->addElement('text', 'lti_typename', get_string('typename','basiclti'));
        $mform->setType('lti_typename', PARAM_INT);
		$mform->setHelpButton('lti_typename', array('typename', get_string('typename', 'basiclti'), 'basiclti'));
		$mform->addRule('lti_typename', null, 'required', null, 'client');
		
		$regex = '/^(http|https):\/\/([a-z0-9-]\.+)*/i';
		
		$mform->addElement('text', 'lti_toolurl', get_string('toolurl','basiclti'),array('size'=>'64'));
        $mform->setType('lti_toolurl', PARAM_TEXT);
		$mform->addRule('lti_toolurl',get_string('validurl','basiclti'), 'regex', $regex, 'client');
		
		$mform->addElement('passwordunmask', 'lti_password', get_string('password','basiclti'));
		$mform->setType('lti_password', PARAM_TEXT);
		
		$mform->addElement('text', 'lti_resourceurl', get_string('resourceurl','basiclti'),array('size'=>'64'));
        $mform->setType('lti_resourceurl', PARAM_TEXT);
		$mform->addRule('lti_resourceurl',get_string('validurl','basiclti'), 'regex', $regex, 'client');
		$mform->setHelpButton('lti_resourceurl', array('resourceurl', get_string('resourceurl', 'basiclti'), 'basiclti'));
		
		$mform->addElement('checkbox', 'lti_preferwidget', get_string('preferwidget', 'basiclti'));
		$mform->setHelpButton('lti_preferwidget', array('preferwidget', get_string('preferwidget', 'basiclti'), 'basiclti'));
		
		$mform->addElement('text', 'lti_preferwidth', get_string('preferwidth','basiclti'));
        $mform->setType('lti_preferwidth', PARAM_INT);
		$mform->setHelpButton('lti_preferwidth', array('preferwidth', get_string('preferwidth', 'basiclti'), 'basiclti'));
		
		$mform->addElement('text', 'lti_preferheight', get_string('preferheight','basiclti'));
        $mform->setType('lti_preferheight', PARAM_INT);
		$mform->setHelpButton('lti_preferheight', array('preferheight', get_string('preferheight', 'basiclti'), 'basiclti'));
		
//-------------------------------------------------------------------------------
        // add standard buttons, common to all modules
        $this->add_action_buttons();

	}	
}

?>
