<?php

/**
 *
 * This file contains some functions used in Simple LTI filter
 *
 * @author Jordi Piguillem
 *
 * @license http://www.gnu.org/copyleft/gpl.html GNU Public License
 * @package basiclti
 */


/**
 * This function generates the params for the request
 *
 * @param string $password		Remote tool password
 *
 * @return string 				Contains all params need for request
 *
 * @TODO: I don't like it. Duplicate code at module. Develop a
 *			generic function.
 *
 */
function basiclti_filter_get_request_params($password){
	global $USER, $COURSE;


	$date = basiclti_get_date();
	$nonce = basiclti_nonce();
	$digest = basiclti_digest($nonce, $date, $password);
	$params =
		'action='.urlencode('launchresolve') . '&' .
		'sec_nonce='.urlencode($nonce) . '&' .
		'sec_created='.urlencode($date) . '&' .
		'sec_digest='.urlencode($digest) . '&' .
		'user_id='.urlencode($USER->id) . '&' .
		'user_role='.urlencode('Instructor') . '&' .
		'user_displayid='.urlencode($USER->username) . '&' .
		'course_id='.urlencode($COURSE->id) . '&' .
		'course_name='.urlencode($COURSE->shortname) . '&' .
		'launch_targets='.urlencode('widget, iframe, post');

	return $params;
}

/**
 * This function treats the server response and formats it
 * to replace the filtered string.
 *
 * @param string $response		Server response
 *
 * @return string 				HTML formated string, ready to print
 *
 * @TODO: Duplicaded code. Can be easily removed.
 *
 */
function basiclti_filter_format_response($response){

	$pattern = '/<status>(?<status>\w+)<\/status>/';
	if (preg_match($pattern, $response, $launchresponse)){
		if ($launchresponse['status'] == 'success'){

			$pattern = '/<type>(?<type>\w+)<\/type>/';
			preg_match($pattern, $response, $launchresponse);
			switch ($launchresponse['type']){
				case 'widget':
					$pattern = '/<widget>(.*?)<\/widget>/sm';
					preg_match($pattern, $response, $launchresponse);
					$response = basiclti_format_widget($launchresponse[1]);
					break;
				case 'iFrame':
					$pattern = '/<launchUrl>(.*?)<\/launchUrl>/';
					preg_match($pattern, $response, $launchresponse);
					$response = basiclti_format_iFrame($launchresponse[1],200);
					break;
				case 'post':
					$pattern = '/<launchUrl>(.*?)<\/launchUrl>/';
					preg_match($pattern, $response, $launchresponse);
					$response = basiclti_format_post($launchresponse[1]);
					break;
				default:
					notice("Unknwon type");
					break;
			}

		} else {
			notice("Connection error");
		}

	}

	return $response;

}

/**
 *
 * @TODO: Doc this function
 */
function basiclti_filter_print_servers(){
	global $CFG, $USER;

	$servers = basiclti_filter_get_servers();
	if (!empty($servers)){
		echo '<ul>';
		foreach ($servers as $server){
			echo '<li>'.
			$server->toolurl.
			'<span class=commands>'.
			'<a class="editing_update" href="settings.php?action=update&amp;id='.$server->id.'&amp;sesskey='.$USER->sesskey.'" title="Update">'.
			'<img class="iconsmall" alt="Update" src="'.$CFG->wwwroot.'/pix/t/edit.gif"/>'.
			'</a>'.
			'<a class="editing_delete" href="settings.php?action=delete&amp;id='.$server->id.'&amp;sesskey='.$USER->sesskey.'" title="Delete">'.
			'<img class="iconsmall" alt="Delete" src="'.$CFG->wwwroot.'/pix/t/delete.gif"/>'.
			'</a>'.
			'</span>'.
			'</li>';

		}
		echo '</ul>';
	} else {
		echo get_string('noservers', 'basiclti');
	}
}

/**
 *
 * @TODO: Doc this function
 */
function basiclti_filter_get_servers(){
	global $DB;
	return $DB->get_records('basiclti_filter');
}

/**
 *
 * @TODO: Doc this function
 */
function basiclti_filter_get_server($id){
	global $DB;
	return $DB->get_record('basiclti_filter',array('id' => $id));
}

/**
 *
 * @TODO: Doc this function
 */
function basiclti_filter_delete_server($id){
	global $DB;
	if ($DB->delete_records ('basiclti_filter', array('id' => $id))){
		notify (get_string('changessaved'), 'notifysuccess');
	} else {
		notify (get_string('errorwithsettings', 'admin'));
	}
}

/**
 *
 * @TODO: Doc this function
 */
function basiclti_filter_get_server_by_url($url){
	global $DB;
	return $DB->get_record('basiclti_filter', array('toolurl' => $url));
}
?>