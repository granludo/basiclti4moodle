<?php
/**
 * 
 * This file contains the Simple LTI global config admin form
 * 
 * @author Jordi Piguillem
 * 
 * @license http://www.gnu.org/copyleft/gpl.html GNU Public License
 * @package basiclti
 */
 
 
require_once ('filteradminlib.php');

$settings->add(new admin_setting_configcheckbox('filter_basiclti_password', 'filter_basiclti_password',
                   get_string('filter_basiclti_password', 'basiclti'), 1));

$settings->add(new admin_setting_basicltifilter_configlink('filter_basiclti_configlink', 'filter_basiclti_configlink',
                   get_string('filter_basiclti_configlink', 'basiclti'), 0));
				   
			   
?>
