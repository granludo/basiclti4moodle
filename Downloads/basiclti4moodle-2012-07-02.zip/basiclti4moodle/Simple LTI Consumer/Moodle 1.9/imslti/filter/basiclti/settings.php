<?php

/**
 *
 * This script is used to clone Moodle admin setting page.
 * It is used to create a new form used to configure trusted servers
 *
 * @author Jordi Piguillem
 *
 * @license http://www.gnu.org/copyleft/gpl.html GNU Public License
 * @package basiclti
 */

require_once('../../config.php');
require_once($CFG->libdir.'/adminlib.php');
require_once('filterlib.php');
require_once('edit_form.php');

global $DB;

$section      = 'filtersettingfilterbasiclti';
$return       = optional_param('return','', PARAM_ALPHA);
$adminediting = optional_param('adminedit', -1, PARAM_BOOL);
$action       = optional_param('action',null, PARAM_TEXT);
$id 	      = optional_param('id',null, PARAM_INT);

/// no guest autologin
require_login(0, false);
$PAGE->set_context(get_context_instance(CONTEXT_SYSTEM));
$PAGE->set_url($CFG->wwwroot . 'filter/basiclti/settings.php', array('section' => $section));
$PAGE->set_pagetype('admin-setting-' . $section);

$adminroot = admin_get_root(); // need all settings
$settingspage = $adminroot->locate($section, true);

if (empty($settingspage) or !($settingspage instanceof admin_settingpage)) {
    print_error('sectionerror', 'admin', "$CFG->wwwroot/$CFG->admin/");
    die;
}

if (!($settingspage->check_access())) {
    print_error('accessdenied', 'admin');
    die;
}

/// WRITING SUBMITTED DATA (IF ANY) -------------------------------------------------------------------------------

$statusmsg = '';
$errormsg  = '';
$focus = '';

if ($data = data_submitted() and confirm_sesskey()) {

	if (isset($id)){
		$data->id = $id;
	    if ($DB->update_record('basiclti_filter', $data)) {
	        $statusmsg = get_string('changessaved');
	    }
	} else {
	    if ($DB->insert_record('basiclti_filter', $data)) {
	        $statusmsg = get_string('changessaved');
	    }
	}
    if (empty($adminroot->errors)) {
        switch ($return) {
            case 'site':  redirect("$CFG->wwwroot/");
            case 'admin': redirect("$CFG->wwwroot/$CFG->admin/");
        }
    } else {
        $errormsg = get_string('errorwithsettings', 'admin');
        $firsterror = reset($adminroot->errors);
        $focus = $firsterror->id;
    }
    $adminroot =& admin_get_root(true); //reload tree
    $page      =& $adminroot->locate($section);
}

if ($PAGE->user_allowed_editing() && $adminediting != -1) {
    $USER->editing = $adminediting;
}


if ($PAGE->user_allowed_editing()) {
    $options = $PAGE->url->params();
    if ($PAGE->user_is_editing()) {
        $caption = get_string('blockseditoff');
        $options['adminedit'] = 'off';
    } else {
        $caption = get_string('blocksediton');
        $options['adminedit'] = 'on';
    }
    $buttons = print_single_button($PAGE->url->out(false), $options, $caption, 'get', '', true);
}

$visiblepathtosection = array_reverse($settingspage->visiblepath);
$navlinks = array();
foreach ($visiblepathtosection as $element) {
    $navlinks[] = array('name' => $element, 'link' => null, 'type' => 'misc');
}
$navigation = build_navigation($navlinks);

print_header("$SITE->shortname: " . implode(": ",$visiblepathtosection), $SITE->fullname, $navigation, $focus, '', true, $buttons, '');

if ($errormsg !== '') {
    notify ($errormsg);

} else if ($statusmsg !== '') {
    notify ($statusmsg, 'notifysuccess');
}

print_heading($settingspage->visiblename);

if ($action == 'add'){
	$form = new filter_basiclti_edit_form();
	$form->display();
} else if ($action == 'update'){
	$form = new filter_basiclti_edit_form('settings.php?id='.$id);
	$server = basiclti_filter_get_server($id);
	$form->set_data($server);
	$form->display();
} else if ($action == 'delete'){
	basiclti_filter_delete_server($id);
	echo '<fieldset>';
	echo '<h4 class="main"><a href="settings.php?action=add&amp;sesskey='.$USER->sesskey.'">'.get_string('addserver','basiclti').'</a></h4>';
	basiclti_filter_print_servers();
	echo '</fieldset>';

} else {
	echo '<fieldset>';
	echo '<h4 class="main"><a href="settings.php?action=add&amp;sesskey='.$USER->sesskey.'">'.get_string('addserver','basiclti').'</a></h4>';
	basiclti_filter_print_servers();
	echo '</fieldset>';
	echo '<div class="mdl-align"><a href="'.$CFG->wwwroot.'/admin/settings.php?section=filtersettingfilterbasiclti">'.get_string('back').'</a></div>';
}

print_footer();

?>
