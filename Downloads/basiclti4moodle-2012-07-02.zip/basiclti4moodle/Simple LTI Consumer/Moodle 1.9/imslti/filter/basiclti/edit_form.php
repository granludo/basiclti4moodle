<?php

/**
 * 
 * This file defines the form used to add trusted servers
 * 
 * @author Jordi Piguillem
 * 
 * @license http://www.gnu.org/copyleft/gpl.html GNU Public License
 * @package basiclti
 */


require_once ($CFG->libdir.'/formslib.php');

class filter_basiclti_edit_form extends moodleform {

    function definition() {
		
		$mform    =& $this->_form;
						
		$regex = '/^(http|https):\/\/([a-z0-9-]\.+)*/i';
		
		$mform->addElement('text', 'toolurl', get_string('toolurl','basiclti'),array('size'=>'64'));
        $mform->setType('toolurl', PARAM_TEXT);
        $mform->addRule('toolurl', null, 'required', null, 'client');
		$mform->addRule('toolurl',get_string('validurl','basiclti'), 'regex', $regex, 'client');
		
		$mform->addElement('passwordunmask', 'password', get_string('password','basiclti'));
		$mform->setType('password', PARAM_TEXT);
		$mform->addRule('password', null, 'required', null, 'client');

        $this->add_action_buttons();
		
		
    }
  
}

?>

